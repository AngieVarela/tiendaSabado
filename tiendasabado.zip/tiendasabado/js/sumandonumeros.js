let num1=10
let num2=25
let resultado = num1 + num2
let num3 = 50
let num4= 10
resultado2 = num3 + num4

//CREANDO UN MAKINON (DECLARAR UNA FUNCION)

function sumar (num1, num2){
    let resultado = num1 + num2
    console.log("la suma es: " +resultado)
}

sumar(10,5)
sumar(10,4)
sumar(10,9)
