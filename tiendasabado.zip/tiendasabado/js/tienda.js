//PRODUCTOS DE LA TIENDA
let nombreProducto="batimovil a escala"
let precioProducto= 450000
let descripcionProducto= "Batimovil de la ultima pelicula de Batman original."
let aplicaDescuento= true

//ARREGLO TRADICIONAL EN JS
let nombresProductos = ["batimovil","camiseta batman"]
let preciosProductos = [450000,70000]

//IMPRIMIR ARREGLO
console.log(nombresProductos)
console.log(nombresProductos[0])

//CREANDO UN OBJETO EN JS
let producto = {
    nombre:"Batimovil",
    precio: 450000,
    descripcion: "Batimovil de la ultima pelicula de Batman original.",
    amigos:["robin", "catwoman"]
}

console.log(producto)
console.log(producto.nombre)
console.log(producto.amigos[0])

